﻿import os
from re import search
from components.ingestion_component import ingestion_component
from components.vectorstore_component.vectorstore_component import VectorStoreComponent
from components.localllm_components.loadlocalllm import LocalLLMComponents
from langchain.retrievers import BM25Retriever, EnsembleRetriever
from utils.storeloaddocstore import LoadStoreDocstore
from langchain.memory import ConversationBufferMemory
from langchain.prompts import PromptTemplate
from langchain.chains import RetrievalQA, ConversationalRetrievalChain
import gradio as gr
import time


if __name__ == "__main__":

    document_store = os.environ.get('DOCUMENT_STORE')

    #ingestion_component.process_documents()
    documents = LoadStoreDocstore().loaddoc()
    #print(documents)
    #VectorStoreComponent().vectoringestion()
    llm = LocalLLMComponents().loadllm()
    index = VectorStoreComponent().load_index()
    faiss_retriever = index.as_retriever(search_kwargs={'k':4})
    bm25_retriever = BM25Retriever.from_documents(documents)
    bm25_retriever.k = 4

    # initialize the ensemble retriever
    ensemble_retriever = EnsembleRetriever(retrievers=[bm25_retriever, faiss_retriever],
                                       weights=[0.5, 0.5])

     
    
    template = """Use the following pieces of context to answer the question at the end. If you don't know the answer,\
    just say that you don't know, don't try to make up an answer.

    {context}

    {chat_history}
    Question: {question}
    Helpful Answer:"""

    #prompt = PromptTemplate(input_variables=["chat_history", "context", "question"], template=template)
    #memory = ConversationBufferMemory(input_key="question", memory_key="chat_history", output_key="answer", return_messages=True)



    #qa = ConversationalRetrievalChain.from_llm(
    #    llm=llm,
    #    chain_type="stuff",
    #    retriever=ensemble_retriever,
    #    return_source_documents=True,
    #    memory=memory,
    #    combine_docs_chain_kwargs={'prompt': prompt},
    #    get_chat_history=lambda h: h,
    #)

    # build conversational retrieval chain with memory (rag) using langchain
    def create_conversation(query: str, chat_history: list) -> tuple:
        try:

            prompt = PromptTemplate(input_variables=["chat_history", "context", "question"], template=template)
            memory = ConversationBufferMemory(input_key="question", memory_key="chat_history", output_key="answer", return_messages=True)
            qa = ConversationalRetrievalChain.from_llm(
                llm=llm,
                chain_type="stuff",
                retriever=ensemble_retriever,
                return_source_documents=True,
                memory=memory,
                combine_docs_chain_kwargs={'prompt': prompt},
                get_chat_history=lambda h: h,
            )

            result = qa({'question': query, 'chat_history': chat_history})
            chat_history.append((query, result['answer']))
            return '', chat_history


        except Exception as e:
            chat_history.append((query, e))
            return '', chat_history

    # build gradio ui
    with gr.Blocks() as demo:
    
        chatbot = gr.Chatbot(label='Chat with your data (Zephyr 7B Alpha)')
        msg = gr.Textbox()
        clear = gr.ClearButton([msg, chatbot])

        msg.submit(create_conversation, [msg, chatbot], [msg, chatbot])
    
    demo.launch()
    #chat_history = []
    ## Interactive questions and answers
    #while True:
    #    query = input("\nEnter a query: ")
    #    if query == "exit":
    #        break
    #    result = qa({"question": query, "chat_history": chat_history})
    #    chat_history.append((query, result['answer']))
    #    #retrieved_docs = ensemble_retriever.get_relevant_documents(query)
    #    #print(retrieved_docs)
    #    # Get the answer from the chain
    #    #res = qa(query)
    #    #answer = res["result"]

    #    # Print the result
    #    print("\n\n> Question:")
    #    print(query)
    #    print("\n> Answer:")
    #    print(result)



