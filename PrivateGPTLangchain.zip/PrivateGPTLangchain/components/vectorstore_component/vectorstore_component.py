from langchain.vectorstores import Chroma
from injector import singleton, inject
import os
from langchain.vectorstores.faiss import FAISS
from utils.storeloaddocstore import LoadStoreDocstore
from components.embedding_component.embedding_component import EmbeddingProcess
from dotenv import load_dotenv
load_dotenv()


#�Load environment variables

index_store = os.environ.get('INDEX_STORE')

@singleton
class VectorStoreComponent:

    @inject
    def __init__(self) -> None:

        self.loadstoredocstore = LoadStoreDocstore()
        self.embeddings = EmbeddingProcess()



    def vectoringestion(self) -> None:

        # Create and store locally vectorstore
        print("Creating new vectorstore")
        documents = self.loadstoredocstore.loaddoc()
        print(f"Creating embeddings. May take some minutes...")
        db = FAISS.from_documents(documents,
                                  self.embeddings.embeddings())
        db.save_local(index_store)


    def load_index(self):

        db = FAISS.load_local(index_store, self.embeddings.embeddings())
        return db