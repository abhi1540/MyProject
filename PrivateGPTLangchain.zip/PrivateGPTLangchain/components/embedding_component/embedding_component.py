from math import sin
from langchain.embeddings import HuggingFaceEmbeddings
from injector import singleton, inject
from dotenv import load_dotenv
import os
load_dotenv()


#�Load environment variables
embedding_model_path = os.environ.get('EMBEDDINGS_MODEL_NAME')
device_type = os.environ.get('DEVICE_TYPE')



@singleton
class EmbeddingProcess:

    @inject
    def __init__(self):

        self.embedding_model_path = embedding_model_path
        self.device_type = device_type


    def embeddings(self):
        embeddings = HuggingFaceEmbeddings(model_name=self.embedding_model_path, model_kwargs={"device": self.device_type})

        return embeddings
