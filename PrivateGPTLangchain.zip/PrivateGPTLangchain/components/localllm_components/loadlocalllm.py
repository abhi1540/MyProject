from langchain.callbacks.streaming_stdout import StreamingStdOutCallbackHandler
from dotenv import load_dotenv
from injector import singleton, inject
from langchain.llms import LlamaCpp
import os
load_dotenv()

model_path = os.environ.get('MODEL_PATH')


@singleton
class LocalLLMComponents:

    @inject
    def __init__(self) -> None:
        self.model_path =  model_path


    def loadllm(self):
       llm = LlamaCpp(model_path=self.model_path,
                      n_ctx=10000,
                      max_tokens=10000,
                      n_batch=512,
                      callbacks=[StreamingStdOutCallbackHandler()],
                      n_gpu_layers=20,
                      verbose=True)
       return llm