


def preprocessing(text: str):
    return text
