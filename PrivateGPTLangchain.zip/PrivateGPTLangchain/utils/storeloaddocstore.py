from math import sin
import pickle
from injector import singleton, inject
from dotenv import load_dotenv
import os
load_dotenv()


#�Load environment variables
document_store = os.environ.get('DOCUMENT_STORE')


@singleton
class LoadStoreDocstore:


    @inject
    def __init__(self) -> None:
        self.filename = document_store

    def storedoc(self, doc):
        with open(self.filename, 'wb') as file:
            pickle.dump(doc, file)


    def loaddoc(self):
        with open(self.filename, 'rb') as file:
            doc = pickle.load(file)
        
        return doc