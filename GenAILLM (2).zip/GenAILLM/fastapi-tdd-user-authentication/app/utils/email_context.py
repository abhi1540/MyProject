USER_VERIFY_ACCOUNT = "verify-account"
FORGOT_PASSWORD = "password-reset"