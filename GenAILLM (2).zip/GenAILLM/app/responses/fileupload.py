from datetime import datetime
from app.responses.base import BaseResponse

class FileUploadResponse(BaseResponse):
    filename: str
