

from datetime import datetime, timedelta
import logging
from sqlalchemy.orm import joinedload
from fastapi import HTTPException
from app.config.security import hash_password, is_password_strong_enough, verify_password, load_user, str_decode, str_encode, generate_token
from app.config.settings import get_settings
from app.utils.string import unique_string
from app.models.user import User, UserToken

settings = get_settings()

async def create_user_account(data, session):
    
    user_exist = session.query(User).filter(User.username == data.username).first()
    if user_exist:
        raise HTTPException(status_code=400, detail="username is already exists.")
    
    if not is_password_strong_enough(data.password):
        raise HTTPException(status_code=400, detail="Please provide a strong password.")
    
    
    user = User()
    user.username = data.username
    user.hashed_password = hash_password(data.password)
    user.updated_at = datetime.utcnow()
    session.add(user)
    session.commit()
    session.refresh(user)
    return user


async def get_login_token(data, session):
    # verify the password
    # generate access_token and refresh_token and ttl
    user = await load_user(data.username, session)

    if not user:
        raise HTTPException(status_code=400, detail="User is not registered with us.")
    
    if not verify_password(data.password, user.hashed_password):
        raise HTTPException(status_code=400, detail="Incorrect password.")
    
        
    # Generate the JWT Token
    return _generate_tokens(user, session)
    
    

def _generate_tokens(user, session):
    refresh_key = unique_string(100)
    access_key = unique_string(50)
    rt_expires = timedelta(minutes=settings.REFRESH_TOKEN_EXPIRE_MINUTES)
    user_token = UserToken()
    user_token.username = user.username
    user_token.refresh_key = refresh_key
    user_token.access_key = access_key
    user_token.expires_at = datetime.utcnow() + rt_expires
    session.add(user_token)
    session.commit()
    session.refresh(user_token)

    at_payload = {
        "sub": str_encode(str(user.username)),
        'a': access_key,
        'r': str_encode(str(user_token.id)),
        'n': str_encode(f"{user.username}")
    }

    at_expires = timedelta(minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES)
    access_token = generate_token(at_payload, settings.JWT_SECRET, settings.JWT_ALGORITHM, at_expires)

    rt_payload = {"sub": str_encode(str(user.username)), "t": refresh_key, 'a': access_key}
    refresh_token = generate_token(rt_payload, settings.SECRET_KEY, settings.JWT_ALGORITHM, rt_expires)
    return {
        "access_token": access_token,
        "refresh_token": refresh_token,
        "expires_in": at_expires.seconds
    }
