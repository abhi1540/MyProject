

from datetime import datetime, timedelta
import logging
from sqlalchemy.orm import joinedload
from fastapi import HTTPException
from app.config.security import hash_password, is_password_strong_enough, verify_password, load_user, str_decode, str_encode, generate_token
from app.config.settings import get_settings
from app.utils.string import unique_string
from app.models.user import User, UserToken
from app.config.security import get_token_user, get_current_user
from fastapi.responses import JSONResponse
from app.services.user import get_login_token


settings = get_settings()




async def apply_embeddings(files, current_user, session):
    print(current_user)
    if current_user:
        return JSONResponse({"message": "Files uploaded and processed successfully"})
    raise HTTPException(
        status_code=401,
        detail="Unauthorized",
    )

    
    
    

