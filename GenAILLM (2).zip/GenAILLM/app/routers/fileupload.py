
from fastapi import APIRouter, BackgroundTasks, Depends, status, Header, UploadFile, File
from fastapi.responses import JSONResponse
from fastapi.security import OAuth2PasswordRequestForm
from sqlalchemy.orm import Session

from app.config.database import get_session
from app.responses.fileupload import FileUploadResponse
from app.schemas.user import RegisterUserRequest
from app.services import fileupload
from typing import List, Annotated
from app.models.user import User, UserToken
from app.config.security import get_current_user


fileupload_router = APIRouter(
    prefix="/auth",
    tags=["Auth"],
    responses={404: {"description": "Not found"}},
)



@fileupload_router.post("/upload", status_code=status.HTTP_200_OK, response_model=FileUploadResponse)
async def file_upload(files: List[UploadFile] = File(...), 
                      current_user: str = Depends(get_current_user), 
                      session: Session = Depends(get_session)):
    return await fileupload.apply_embeddings(files, current_user, session)



