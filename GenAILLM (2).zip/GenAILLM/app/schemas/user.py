

from pydantic import BaseModel, EmailStr


class RegisterUserRequest(BaseModel):
    username: str
    password: str
    
    
class VerifyUserRequest(BaseModel):
    token: str
    email: EmailStr
    
    