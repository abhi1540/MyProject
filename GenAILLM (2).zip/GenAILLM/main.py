import uvicorn
from app.api import app
from fastapi.middleware.cors import CORSMiddleware

# Define CORS settings
origins = ["*"]  # Allow requests from any origin



# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["GET", "POST", "PUT", "DELETE", "OPTIONS"],
    allow_headers=["*"],
)


if __name__ == "__main__":
    uvicorn.run("app.api:app", host='0.0.0.0', port=8000, reload=True)
