(privategpt) D:\Workspace\GenAILLM\fastapi-tdd-user-authentication>alembic revision --autogenerate -m "create my table table"
INFO  [alembic.runtime.migration] Context impl PostgresqlImpl.
INFO  [alembic.runtime.migration] Will assume transactional DDL.
INFO  [alembic.autogenerate.compare] Detected added table 'users'
INFO  [alembic.autogenerate.compare] Detected added index ''ix_users_username'' on '('username',)'
Generating D:\Workspace\GenAILLM\fastapi-tdd-user-authentication\alembic\versions\2b965d9c65ad_create_my_table_table.py ...  done

(privategpt) D:\Workspace\GenAILLM\fastapi-tdd-user-authentication>alembic upgrade head
INFO  [alembic.runtime.migration] Context impl PostgresqlImpl.
INFO  [alembic.runtime.migration] Will assume transactional DDL.
INFO  [alembic.runtime.migration] Running upgrade  -> 2b965d9c65ad, create my table table

(privategpt) D:\Workspace\GenAILLM\fastapi-tdd-user-authentication>


(privategpt) D:\Workspace\GenAILLM>alembic revision --autogenerate -m "create user_token table"
INFO  [alembic.runtime.migration] Context impl PostgresqlImpl.
INFO  [alembic.runtime.migration] Will assume transactional DDL.
INFO  [alembic.autogenerate.compare] Detected added table 'user_tokens'
INFO  [alembic.autogenerate.compare] Detected added index ''ix_user_tokens_access_key'' on '('access_key',)'
INFO  [alembic.autogenerate.compare] Detected added index ''ix_user_tokens_refresh_key'' on '('refresh_key',)'
Generating D:\Workspace\GenAILLM\alembic\versions\7dffb1a01dc5_create_user_token_table.py ...  Done