from typing import Union
from datetime import datetime
from pydantic import BaseModel
from app.responses.base import BaseResponse
import uuid

class UserResponse(BaseResponse):
    id: uuid
    username: str
    created_at: Union[str, None, datetime] = None
    
    

class LoginResponse(BaseModel):
    access_token: str
    refresh_token: str
    expires_in: int
    token_type: str = "Bearer"
